//
//  ViewController.swift
//  gpscode
//
//  Created by TOPS on 8/3/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
class ViewController: UIViewController,CLLocationManagerDelegate {

    @IBOutlet weak var map: MKMapView!
    let manager = CLLocationManager();
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        map.showsUserLocation = true;
        
        manager.delegate = self;
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
        manager.requestAlwaysAuthorization();
        manager.requestWhenInUseAuthorization();
        
        manager.startUpdatingLocation();
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        
        let cls = locations[0];
        print(cls.coordinate.latitude);
        print(cls.coordinate.longitude);
        
        
        CLGeocoder().reverseGeocodeLocation(cls, completionHandler: {(placemarks, error) -> Void in
            
            if error != nil {
                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                return
            }
            
            if (placemarks?.count)! > 0 {
                let pm = placemarks?[0]
                print(pm?.locality!)
                print(pm?.country!)
                print(pm?.postalCode!)
                print(pm?.name!)
                print(pm?.subLocality!)
                // print(pm?.ocean!)
                
            }
            else {
                print("Problem with the data received from geocoder")
            }
        })
        
        let center = CLLocationCoordinate2D(latitude: cls.coordinate.latitude, longitude: cls.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        self.map.setRegion(region, animated: true)
        let newYorkLocation = CLLocationCoordinate2DMake(cls.coordinate.latitude, cls.coordinate.longitude)
        let dropPin = MKPointAnnotation()
        dropPin.coordinate = newYorkLocation
        
        dropPin.title = "New York City"
        map.addAnnotation(dropPin)
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

